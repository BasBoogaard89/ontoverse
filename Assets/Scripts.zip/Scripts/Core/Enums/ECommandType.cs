public enum ECommandType
{
    Help,

    Unknown
}
