public enum EDialogueStepType
{
    Type,
    Wait,
    FakeUserInput,
    Prompt,

    Unknown
}
