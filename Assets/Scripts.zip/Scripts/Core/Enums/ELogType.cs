public enum ELogType
{
    None,
    System,
    Input,

    Unknown
}
