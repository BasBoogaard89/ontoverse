/// <summary>
/// Corpus describes a ship
/// </summary>
public class Corpus
{
    public string Name;
}
