/// <summary>
/// Node describes a planet
/// </summary>
public class Node
{
    public string Name;
}
