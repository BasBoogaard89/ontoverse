using System.Collections.Generic;

/// <summary>
/// Directory describes a star system
/// </summary>
public class Directory2
{
    public string Name;
    public List<Node> Nodes;
}
