using UnityEngine;

public class GameState : MonoBehaviour
{
    void Start()
    {
        Application.targetFrameRate = 30;
    }
}
