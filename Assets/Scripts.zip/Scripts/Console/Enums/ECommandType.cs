public enum ECommandType
{
    None,
    Help,

    Unknown
}
