public enum ELogType
{
    None,
    System,
    Input,
    User,
    Unknown
}
