public enum EStepType
{
    Type,
    Wait,
    Button,
    Command,
    Action,
}
