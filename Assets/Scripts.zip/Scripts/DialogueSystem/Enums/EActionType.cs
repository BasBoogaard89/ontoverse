public enum EActionType
{
    ExplodeUniverse
}
