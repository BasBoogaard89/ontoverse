public enum EDisplayType
{
    Type,
    UserInput,
    Prompt
}
