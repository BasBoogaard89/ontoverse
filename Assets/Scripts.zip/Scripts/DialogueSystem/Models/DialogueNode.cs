﻿using Newtonsoft.Json;
using System;
using UnityEngine;

public class DialogueNode
{
    public string Id;
    public BaseStep Step;
    public string NextNodeId;
    public float PositionX;
    public float PositionY;

    [JsonIgnore]
    public Vector2 Position => new(PositionX, PositionY);

    public DialogueNode()
    {
        Id = Guid.NewGuid().ToString();
    }

    public DialogueNode(string id)
    {
        Id = id;
    }
}