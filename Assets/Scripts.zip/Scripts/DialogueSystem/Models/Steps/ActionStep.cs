public class ActionStep : BaseStep
{
    public override EStepType StepType => EStepType.Action;

    public ActionStep()
    {
    }
}
