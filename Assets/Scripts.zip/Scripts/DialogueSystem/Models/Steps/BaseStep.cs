public abstract class BaseStep
{
    public abstract EStepType StepType { get; }
}