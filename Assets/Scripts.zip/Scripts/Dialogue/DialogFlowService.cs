﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class DialogueFlowService : MonoBehaviour
{
    public static DialogueFlowService Instance { get; private set; }

    public TerminalTyper Typer;

    public DialogueFlowController ActiveFlow { get; private set; }

    public event Action<List<DialogueButtonData>> OnButtonsPresented;
    public event Action OnCommandWaiting;
    public event Action OnFlowEnded;

    private void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    public void StartFlow(DialogueGraph graph)
    {
        ActiveFlow = new DialogueFlowController(graph);

        ActiveFlow.OnTextOutput += Typer.PrintLine;
        ActiveFlow.OnButtonsPresented += buttons =>
        {
            OnButtonsPresented?.Invoke(buttons);
        };
        ActiveFlow.OnCommandRequired += () =>
        {
            OnCommandWaiting?.Invoke();
        };
        ActiveFlow.OnFlowEnded += () =>
        {
            OnFlowEnded?.Invoke();
        };

        Typer.OnStepComplete += ActiveFlow.NotifyStepFinished;

        ActiveFlow.StartFlow();
    }

    public void StartFlowFromResource(string resourcePath)
    {
        TextAsset json = Resources.Load<TextAsset>(resourcePath);

        if (json == null)
        {
            Debug.LogError($"DialogueFlowService: Resource not found at '{resourcePath}'");
            return;
        }

        DialogueGraph graph = JsonUtility.FromJson<DialogueGraph>(json.text);
        StartFlow(graph);
    }

    public void SubmitCommand(string cmd)
    {
        Typer.PrintLine(new DialogueStep(EDialogueStepType.FakeUserInput, cmd));
        ActiveFlow?.SubmitCommand(cmd);
    }

    public void SelectButton(int index)
    {
        ActiveFlow?.SelectButton(index);
    }
}
