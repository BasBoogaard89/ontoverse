﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class DialogueFlowController
{
    private DialogueGraph Graph;
    private DialogueNode CurrentNode;

    public event Action<DialogueStep> OnTextOutput;
    public event Action<List<DialogueButtonData>> OnButtonsPresented;
    public event Action OnCommandRequired;
    public event Action OnFlowEnded;

    private bool WaitingForTyper = false;

    public DialogueFlowController(DialogueGraph loadedGraph)
    {
        Graph = loadedGraph;
        CurrentNode = Graph.GetNodeById(Graph.EntryNodeId);
    }

    public void StartFlow()
    {
        if (CurrentNode != null)
            ExecuteCurrentStep();
        else
            Debug.LogError("No entry node found.");
    }

    public void SubmitCommand(string cmd)
    {
        var step = CurrentNode.Step;

        if (!step.WaitForCommand)
        {
            Debug.LogWarning("Not waiting for a command.");
            return;
        }

        bool isValid = ValidateCommand(cmd, step);

        if (isValid)
        {
            Continue();
        } else
        {
            ExecuteCurrentStep();
        }
    }

    public void SelectButton(int index)
    {
        if (!CurrentNode.Step.PresentButtons || index < 0 || index >= CurrentNode.Step.Buttons.Count)
        {
            Debug.LogWarning("Invalid button index.");
            return;
        }

        var targetId = CurrentNode.Step.Buttons[index].TargetNodeId;
        if (!string.IsNullOrEmpty(targetId))
        {
            CurrentNode = Graph.GetNodeById(targetId);
            ExecuteCurrentStep();
        } else
        {
            Debug.LogWarning("Button has no linked target node.");
        }
    }

    private void ExecuteCurrentStep()
    {
        var step = CurrentNode.Step;

        if (step.ClearBefore)
            OnTextOutput?.Invoke(null);

        WaitingForTyper = true;
        OnTextOutput?.Invoke(step);
    }

    public void NotifyStepFinished()
    {
        if (!WaitingForTyper)
            return;

        WaitingForTyper = false;

        var step = CurrentNode.Step;

        if (step.PresentButtons)
        {
            OnButtonsPresented?.Invoke(step.Buttons);
        } else if (step.WaitForCommand)
        {
            OnCommandRequired?.Invoke();
        } else if (!step.RequiresUserInput)
        {
            Continue();
        }
    }

    public void Continue()
    {
        if (CurrentNode.Step.PresentButtons)
            return;

        if (CurrentNode.NextNodeIds.Count > 0)
        {
            CurrentNode = Graph.GetNodeById(CurrentNode.NextNodeIds[0]);
            ExecuteCurrentStep();
        } else
        {
            OnFlowEnded?.Invoke();
        }
    }

    private bool ValidateCommand(string cmd, DialogueStep step)
    {
        return cmd == "help" && step.CommandType == ECommandType.Help;
    }
}
