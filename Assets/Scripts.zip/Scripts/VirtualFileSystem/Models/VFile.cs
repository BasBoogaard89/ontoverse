﻿public class VFile
{
    public string Name;
    public string Content;
}