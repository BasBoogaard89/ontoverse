using System;
using System.Collections.Generic;

public class TerminalSequence
{
    public List<DialogueStep> Steps;
    public Action OnSequenceComplete;

    public TerminalSequence(List<DialogueStep> steps, Action onComplete = null)
    {
        Steps = steps;
        OnSequenceComplete = onComplete;
    }
}
