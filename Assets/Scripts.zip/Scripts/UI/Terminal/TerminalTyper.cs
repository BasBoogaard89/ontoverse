﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class TerminalTyper : MonoBehaviour
{
    [SerializeField] private VisualTreeAsset terminalLineTemplate;
    [SerializeField] private bool EnableDelays = true;

    private ScrollView scrollView;
    private VisualElement lineContainer;

    private Queue<DialogueStep> StepQueue = new();
    private bool IsRunningSequence = false;

    public Action OnTyperComplete;
    public Action<List<DialogueButtonData>> OnButtonsPresented;
    public Action OnStepComplete;

    private VisualElement ActiveInputLine;

    private string LogTypeClass = "log-type";
    private string LogTextClass = "log-text";

    private void Awake()
    {
        scrollView = GetComponent<UIDocument>().rootVisualElement.Q<ScrollView>("ScrollView");
        lineContainer = scrollView.Q("unity-content-container");
    }

    public void PrintLine(DialogueStep step)
    {
        StepQueue.Enqueue(step);
        if (!IsRunningSequence)
            StartCoroutine(ProcessSteps());
    }

    public void HandleButtons(List<DialogueButtonData> buttons)
    {
        OnButtonsPresented?.Invoke(buttons);
    }

    private IEnumerator ProcessSteps()
    {
        IsRunningSequence = true;

        while (StepQueue.Count > 0)
        {
            var step = StepQueue.Dequeue();

            if (step.ClearBefore)
                lineContainer.Clear();

            if (EnableDelays && step.Delay > 0)
                yield return new WaitForSeconds(step.Delay);

            switch (step.StepType)
            {
                case EDialogueStepType.Wait:
                    break;

                case EDialogueStepType.Type:
                    yield return StartCoroutine(TypeLine(step));
                    break;

                case EDialogueStepType.FakeUserInput:
                    yield return StartCoroutine(TypeLine(step, ">"));
                    break;

                case EDialogueStepType.Prompt:
                    yield return StartCoroutine(StartWithPrompt(step));
                    break;
            }
        }

        IsRunningSequence = false;
        OnTyperComplete?.Invoke();
        OnStepComplete?.Invoke();
    }

    private IEnumerator TypeLine(DialogueStep step, string prefix = null)
    {
        var line = AddLineFromStep(step, prefix);
        var textLabel = line.Q<Label>(LogTextClass);

        if (step.CharacterDelay <= 0f || !EnableDelays)
        {
            textLabel.text += step.Text;
        } else
        {
            for (int i = 0; i < step.Text.Length; i++)
            {
                textLabel.text += step.Text[i];
                yield return AddDelay(step.CharacterDelay);
            }
        }

        ScrollToBottom();
    }

    private IEnumerator StartWithPrompt(DialogueStep step, string prompt = "C:\\>", int blinkCount = 3, float blinkSpeed = 0.3f)
    {
        var line = AddLineFromStep(step);
        var textLabel = line.Q<Label>(LogTextClass);

        for (int i = 0; i < blinkCount * 2; i++)
        {
            textLabel.text = prompt + (i % 2 == 0 ? "█" : " ");
            yield return AddDelay(blinkSpeed);
        }

        textLabel.text = prompt;
        yield return StartCoroutine(TypeOnExistingLabel(textLabel, step.Text, step.CharacterDelay));
    }

    private IEnumerator TypeOnExistingLabel(Label label, string content, float characterDelay)
    {
        for (int i = 0; i < content.Length; i++)
        {
            label.text += content[i];
            yield return AddDelay(characterDelay);
        }

        ScrollToBottom();
    }

    private IEnumerator AddDelay(float delay)
    {
        if (EnableDelays && delay > 0)
            yield return new WaitForSeconds(delay);
    }

    private void ScrollToBottom()
    {
        scrollView.schedule.Execute(() =>
        {
            scrollView.scrollOffset = new Vector2(0, float.MaxValue);
        }).ExecuteLater(1);
    }

    private VisualElement AddLineFromStep(DialogueStep step, string prefix = null)
    {
        var line = terminalLineTemplate.Instantiate();
        var typeLabel = line.Q<Label>(LogTypeClass);
        var textLabel = line.Q<Label>(LogTextClass);

        if (step.LogType == ELogType.None)
            typeLabel.style.display = DisplayStyle.None;
        else
        {
            typeLabel.text = UIExtensions.GetDialogueColorTag(step.LogType) +
                             UIExtensions.GetDialogueStepTerminalPrefix(step);
            typeLabel.style.display = DisplayStyle.Flex;
        }

        textLabel.text = UIExtensions.GetDialogueColorTag(step.LogType) + (prefix ?? "");

        if (step.LogType == ELogType.Input || step.StepType == EDialogueStepType.FakeUserInput)
        {
            ResetActiveInputLine();
            ActiveInputLine = line;
        }

        lineContainer.Add(line);
        return line;
    }

    private void ResetActiveInputLine()
    {
        if (ActiveInputLine == null)
            return;

        var typeLabel = ActiveInputLine.Q<Label>(LogTypeClass);
        var textLabel = ActiveInputLine.Q<Label>(LogTextClass);

        if (typeLabel != null) typeLabel.text = UIExtensions.StripRichText(typeLabel.text);
        if (textLabel != null) textLabel.text = UIExtensions.StripRichText(textLabel.text);

        ActiveInputLine = null;
    }
}
