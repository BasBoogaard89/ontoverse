using System.Collections.Generic;
using UnityEngine;

public class UserConsolePanel : BasePanel
{
    CommandInput CommandInput;
    List<string> currentOptions = new();

    void Start()
    {
        CommandInput = GetComponent<CommandInput>();
        CommandInput.OnRunCommand = RunCommand;

        var flow = DialogueFlowService.Instance;

        if (flow != null && flow.ActiveFlow != null)
        {
            flow.ActiveFlow.OnButtonsPresented += ShowOptionButtons;
            flow.ActiveFlow.OnCommandRequired += ShowCommandPrompt;
        }
    }

    void RunCommand(string cmd)
    {
        DialogueFlowService.Instance.SubmitCommand(cmd);

        Hide();
    }

    void ShowCommandPrompt()
    {
        Show();
    }

    void ShowOptionButtons(List<DialogueButtonData> buttons)
    {
        currentOptions.Clear();
        foreach (var btn in buttons)
        {
            currentOptions.Add(btn.Label);
        }

        Show();
    }

    void OnGUI()
    {
        if (currentOptions.Count == 0)
            return;

        GUILayout.BeginArea(new Rect(10, 10, 300, 500));
        GUILayout.Label("Choose an option:");

        for (int i = 0; i < currentOptions.Count; i++)
        {
            if (GUILayout.Button(currentOptions[i]))
            {
                DialogueFlowService.Instance.SelectButton(i);
                currentOptions.Clear();
                Hide();
            }
        }

        GUILayout.EndArea();
    }

}
