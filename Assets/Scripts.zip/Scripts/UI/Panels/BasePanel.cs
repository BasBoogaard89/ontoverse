using UnityEngine;

public abstract class BasePanel : MonoBehaviour
{
    public TerminalTyper Typer;
    public bool IsPanelEnabled { private set; get; }

    public virtual void Show()
    {
        gameObject.SetActive(true);
    }

    public virtual void Hide()
    {
        gameObject.SetActive(false);
    }

    public virtual void Init() { }

    public void SetPanelEnabled(bool doSet)
    {
        IsPanelEnabled = doSet;
    }
}
