﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class CommandInput : MonoBehaviour
{
    private TextField CommandInputField;
    private VisualElement AutocompleteList;
    private Button RunButton;

    private bool AutocompleteEnabled = false;
    private List<string> Suggestions = new() { "help", "does", "this", "fucker", "freaking1" , "freaking2" , "freaking3" , "freaking4" , "freaking" };
    private List<Label> SuggestionItems = new();
    private int SelectedIndex = -1;
    private int MaxVisibleSuggestions = 5;

    private string ItemClass = "autocomplete-item";
    private string HighlightClass = "highlight";
    public Action<string> OnRunCommand;

    private void Awake()
    {
        var root = GetComponent<UIDocument>().rootVisualElement;

        CommandInputField = root.Q<TextField>("command-input");
        AutocompleteList = root.Q<VisualElement>("autocomplete-list");
        RunButton = root.Q<Button>("run-button");

        CommandInputField.RegisterCallback<FocusInEvent>(OnFocus);
        CommandInputField.RegisterValueChangedCallback(OnInputChanged);
        CommandInputField.RegisterCallback<KeyDownEvent>(OnKeyDown);
        CommandInputField.RegisterCallback<FocusOutEvent>(evt =>
        {
            CommandInputField.schedule.Execute(HideSuggestions).ExecuteLater(100);
        });

        RunButton.RegisterCallback<ClickEvent>(_ => RunCommand(CommandInputField.value));

        Suggestions.Sort(StringComparer.OrdinalIgnoreCase);

        HideSuggestions();
    }

    private void OnFocus(FocusInEvent evt)
    {
        CommandInputField.schedule.Execute(_ =>
        {
            CommandInputField.SelectRange(CommandInputField.value.Length, CommandInputField.value.Length);
        }).ExecuteLater(100);

        evt.StopPropagation();
    }

    private void OnInputChanged(ChangeEvent<string> evt)
    {
        string input = evt.newValue;

        if (!AutocompleteEnabled || string.IsNullOrWhiteSpace(input))
        {
            HideSuggestions();
            return;
        }

        var matches = Suggestions.FindAll(s => s.StartsWith(input, StringComparison.OrdinalIgnoreCase));
        if (matches.Count == 0)
        {
            HideSuggestions();
            return;
        }

        ShowSuggestions(matches);
    }

    private void OnKeyDown(KeyDownEvent evt)
    {
        if (evt.keyCode == KeyCode.Backspace || (evt.character != '\0' && !char.IsControl(evt.character)))
        {
            AutocompleteEnabled = true;
        }

        if (evt.keyCode == KeyCode.Return || evt.keyCode == KeyCode.KeypadEnter)
        {
            if (AutocompleteList.style.display != DisplayStyle.None &&
                SelectedIndex >= 0 &&
                SelectedIndex < SuggestionItems.Count)
            {
                evt.StopPropagation();
                SetInput(SuggestionItems[SelectedIndex].text);
            }
            else
            {
                evt.StopPropagation();
                RunCommand(CommandInputField.value);
            }
            return;
        }

        if (AutocompleteList.style.display == DisplayStyle.None)
            return;

        if (evt.keyCode == KeyCode.DownArrow)
        {
            evt.StopPropagation();
            MoveSelection(1);
        }
        else if (evt.keyCode == KeyCode.UpArrow)
        {
            evt.StopPropagation();
            MoveSelection(-1);
        }
    }

    private void SetInput(string text)
    {
        CommandInputField.value = text;
        CommandInputField.Focus();

        HideSuggestions();
        AutocompleteEnabled = false;
    }

    private void ShowSuggestions(List<string> matches)
    {
        AutocompleteList.Clear();
        SuggestionItems.Clear();
        SelectedIndex = -1;

        var limitedMatches = matches.Count > MaxVisibleSuggestions
            ? matches.GetRange(0, MaxVisibleSuggestions)
            : matches;

        foreach (var match in limitedMatches)
        {
            var item = new Label(match);
            item.AddClass(ItemClass);

            item.RegisterCallback<ClickEvent>(_ =>
            {
                SetInput(match);
                HideSuggestions();
            });

            item.RegisterCallback<MouseOverEvent>(_ =>
            {
                foreach (var item in SuggestionItems)
                    item.RemoveClass(HighlightClass);

                item.AddClass(HighlightClass);
                SelectedIndex = SuggestionItems.IndexOf(item);
            });

            AutocompleteList.Add(item);
            SuggestionItems.Add(item);
        }

        AutocompleteList.style.display = DisplayStyle.Flex;
    }

    private void HideSuggestions()
    {
        AutocompleteList.style.display = DisplayStyle.None;
        SelectedIndex = -1;
    }

    private void MoveSelection(int direction)
    {
        if (SuggestionItems.Count == 0)
            return;

        if (SelectedIndex >= 0 && SelectedIndex < SuggestionItems.Count)
            SuggestionItems[SelectedIndex].AddClass(HighlightClass);

        SelectedIndex += direction;

        if (SelectedIndex < 0)
            SelectedIndex = SuggestionItems.Count - 1;
        else if (SelectedIndex >= SuggestionItems.Count)
            SelectedIndex = 0;

        SuggestionItems[SelectedIndex].AddClass(HighlightClass);
    }

    private void RunCommand(string cmd)
    {
        if (string.IsNullOrWhiteSpace(cmd) || cmd.Equals("Enter a command..."))
            return;

        if (Suggestions.Contains(cmd))
        {
            Debug.Log("Running command: " + cmd);

            OnRunCommand?.Invoke(cmd);

            CommandInputField.value = "Enter a command...";
        }
        
        HideSuggestions();
    }
}
