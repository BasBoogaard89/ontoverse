using System;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    public UserConsolePanel UserConsolePanel;
    public Action UserConsolePanelEnabled;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) && UserConsolePanel.IsPanelEnabled)
        {
            bool isActive = UserConsolePanel.gameObject.activeSelf;

            if (isActive)
            {
                UserConsolePanel.Hide();
            }
            else
            {
                UserConsolePanel.Show();
                UserConsolePanelEnabled?.Invoke();
            }
        }
    }

    public void EnableUserConsolePanel()
    {
        UserConsolePanel.SetPanelEnabled(true);
    }
}
